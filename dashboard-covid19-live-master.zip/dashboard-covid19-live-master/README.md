# Dashboard COVID-19 Sederhana

Repo ini merupakan kode dari Live Streaming Video Youtube #NgodingBareng [LIVE] Membuat Dashboard Informasi Kasus COVID-19 di Indonesia yang bisa dilihat pada link berikut :
[#NgodingBareng [LIVE] Membuat Dashboard Informasi Kasus COVID-19 di Indonesia](https://www.youtube.com/watch?v=J89AGDa8-YY&t=4662s)

## Authors

* **Afif A. Iskandar** - [NgodingPython](https://youtube.com/NgodingPython)
